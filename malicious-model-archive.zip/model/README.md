# Safe model
Nothing to see here.